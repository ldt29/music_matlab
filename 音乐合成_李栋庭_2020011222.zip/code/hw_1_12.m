clc;clear;

com_music();

